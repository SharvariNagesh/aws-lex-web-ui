
import json
import datetime
import time
import os
import dateutil.parser
import logging
import os, ssl
import ssl
import re
import copy
import boto3

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
RETRY_COUNT = 3
BUCKET="dermo-bot-log-bucket-2"
MODEL_ARN='arn:aws:rekognition:us-east-1:972407487200:project/skin-diseases-classifier-project/version/skin-diseases-classifier-project.2022-03-07T21.23.17/1646668396027'


def get_disease(photo):

    logger.debug("Image file name:" + photo)
    try:  
        # photo="download (9).jpg"
        client=boto3.client('rekognition', 'us-east-1')
        #process using S3 object
        
        response = client.detect_custom_labels(Image={'S3Object': {'Bucket': BUCKET, 'Name': photo}},
            MinConfidence=30,
            ProjectVersionArn=MODEL_ARN)    
        logger.debug("Response from Rekognize")
        logger.debug(response)
        
        #Get the custom labels
        if response is not None:
            labels=response['CustomLabels']
            logger.debug("Label name:" )
            logger.debug(labels)
            return labels[0]["Name"]
        else:
            return None
    except:
        logger.debug("Exception thrown while extracting rekognition value")
        return None
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps(labels)
    # }

def close(sessionAttributes, fulfillmentState, message):
    
    response = {
        'sessionState':{
        'sessionAttributes': sessionAttributes,
        'dialogAction': {
            'type': 'Close'
        },
        'intent': {
            'confirmationState': "Confirmed",
            'name': "BillInformation",
            'state': fulfillmentState
        }
        },
        'messages':[
            {
                'contentType':'PlainText',
                'content':message
            }
        ]
    }    
    return response


    

def get_slot_value(sessionAttributes,intentName, slotToElicit,messageText, options):
    # messageText = "" 

    # if (not try_ex(lambda:sessionAttributes['retries'])) :
    #     sessionAttributes['retries'] = 0
        
    # if int(sessionAttributes['retries']) >= RETRY_COUNT :
    #     logger.warn("retries has exceeded RETRY_COUNT" + str(policies) + str(sessionAttributes))
    #     sessionAttributes['retries'] = 0
    #     return close(sessionAttributes,"Failed","You have exceeded maximum retries. Please try again later.")
    # elif int(sessionAttributes['retries']) > 0 and int(sessionAttributes['retries']) < RETRY_COUNT:    
    #     messageText = "<p>You have selected a wrong value! </p>" + messageText
    #     sessionAttributes['retries'] = int(sessionAttributes['retries']) + 1
    # else :
    #     sessionAttributes['retries'] = int(sessionAttributes['retries']) + 1
        
   
    messaButtons = []
    if options is not None :
        for button in options:
            messaButtons.append( {
                "text" : button,
                "value" : button
            })
    return elicit_slot(sessionAttributes, intentName, slotToElicit, messageText, messaButtons)
    

def elicit_slot(sessionAttributes, intentName, slotToElicit, messageText, messageButtons):
    
    response = {
        'sessionState':{
        'sessionAttributes': sessionAttributes,
		"dialogAction": {
			"slotToElicit": slotToElicit,
			"type": "ElicitSlot"
		},
        'intent': {
            'confirmationState': "None",
            'name': intentName,
            "slots": {
                slotToElicit: None
            },
            'state': "InProgress"
        }
        },
        'messages':[          
            {
                'content': messageText,
                'contentType': 'PlainText'
            },
            {
                'contentType':"ImageResponseCard",
                'imageResponseCard': {
                    'title': 'Select Yes/No',
                    'buttons': messageButtons
                }
            }
        ]
    }
    logger.debug(response)
    return response
    

def confirm_intent(sessionAttributes, intentName, slots, message):
    return {
        'sessionAttributes': sessionAttributes,
        'dialogAction': {
            'type': 'ConfirmIntent',
            'intentName': intentName,
            'slots': slots,
            'message': message
        }
    }
    
def delegate(sessionAttributes, slots):
    return {
        'sessionAttributes': sessionAttributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }
    
def try_ex(func):
    """
    Call passed in function in try block. If KeyError is encountered return None.
    This function is intended to be used to safely access dictionary.

    Note that this function would have negative impact on performance.
    """
    try:
        return func()
    except KeyError:
        
        return None

def extract_slot_value(intentRequest, slotName, sessionAttributes):
    try:
        return intentRequest['interpretations'][0]['intent']['slots'][slotName]['value']['interpretedValue']
    except:
        try:
            return sessionAttributes[slotName] 
        except:
            return None
        

def handle_skin_issue(intentRequest):
    
    analysis = ""
    sessionAttributes = try_ex(lambda: intentRequest['sessionState']['sessionAttributes'])
    fileUploadStatus = extract_slot_value(intentRequest, 'FileUploadStatus',sessionAttributes) 
    # duration = try_ex(lambda: intentRequest['sessionState']['intent']['slots']['time']['value']['interpretedValue'])
    duration = extract_slot_value(intentRequest, 'time', sessionAttributes)
    # extractSlotValue(intentRequest, 'time')
    injury =  extract_slot_value(intentRequest, 'injury',sessionAttributes)
    itching = extract_slot_value(intentRequest, 'itching', sessionAttributes) 
    isChanging = extract_slot_value(intentRequest, 'isChanging', sessionAttributes) 
    # # isChanging = try_ex(lambda: intentRequest['sessionState']['intent']['slots']['isChanging']['value']['interpretedValue'])
    intentName = try_ex(lambda: intentRequest['interpretations'][0]['intent']['name'])
    yesNo = ['Yes', 'No']
    logger.debug("duration " + str(duration))
    logger.debug("fileUploadStatus" + str(fileUploadStatus))
    logger.debug("injury" + str(injury))
    logger.debug("itching" + str(itching))
    logger.debug("isChanging" + str(isChanging))
    
    logger.debug(intentRequest)
    # logger.debug(intentRequest)
    
    
    # logger.info(sessionAttributes)
    # logger.info("FileUploadStatus")
    # logger.info(intentRequest['sessionState']['intent']['slots']['FileUploadStatus'])
    
    if duration is None:
        logger.info("Duration is None. eliciting duration")
        messageText = "Since how many days do you have this condition?"
        return get_slot_value(sessionAttributes,intentName, 'time',messageText, None)
        # return elicit_slot(sessionAttributes, intentName, )
    elif try_ex(lambda: sessionAttributes['time']) is None:
        sessionAttributes['time'] = intentRequest['sessionState']['intent']['slots']['time']['value']['interpretedValue']
        
    if fileUploadStatus is None:
        logger.debug("FileUploadStatus is None. Uploading the file")
        sessionAttributes['UploadFile']=True
        messageText = "Please upload an image of the affected area."
        logger.info("Eliciting file upload")
        return get_slot_value(sessionAttributes,intentName, 'FileUploadStatus',messageText, None)
        # return elicit_slot(sessionAttributes, intentName, "FileUploadStatus", messageText, ['Yes', 'No'])
    elif try_ex(lambda: sessionAttributes['FileUploadStatus']) is None:
        sessionAttributes['UploadFile']=False
        sessionAttributes['FileUploadStatus'] = intentRequest['sessionState']['intent']['slots']['FileUploadStatus']['value']['interpretedValue']
        
    
    # Here here we have to call rekognize function to recognize the image.
    # sessionAttributes['uploadedFileName'] will have uploaded file. use the file name to call rekognition
    
    if(sessionAttributes['diseaseFileName'] is not None):
        analysis = get_disease(sessionAttributes['diseaseFileName'])
        logger.debug("Rekognize returned: " )
        logger.debug(analysis)
    else:
         return close(sessionAttributes, "Fulfilled", "Sorry for the inconvenience. At the moment, our Rekognize function is not working.")
    
    sessionAttributes['fileUploadStatus'] = fileUploadStatus
    if analysis == 'Psoriasis':
        if itching is None:
            messageText = "Do you have any itching or soreness in the area?"
            return get_slot_value(sessionAttributes,intentName, 'itching',messageText, yesNo)
            # return elicit_slot(sessionAttributes, intentName, itching, )
        else:
            sessionAttributes['itching'] = itching     
    
       
        message = """
          By looking at the image and based upon your inputs, we have diagnosed this condition as <b>Psoriasis</b>. 
          <br>Here are some home remedies which are known to provide relief from psoriases:
          <ul>
           <li>Use moisturizer, Aloe vera and turmeric. </li>
           <li>Expose your skin to small amounts of sunlight.</li>
           <li>Avoid psoriasis triggers such as injuries, alcohol/smoking.</li>
           <li>Start Stress-relieving activities like yoga/meditation </li>
          </ul>
          <b>Note: </b>
          If condition worsens, please consult a doctor immediately.
          <br> <b> Thanks for using DermoBot. Is there anything else I can help you with?</b>
        """
        logger.debug("Processing is complete for psoriases. Returning the message:" + message)
        sessionAttributes={}
        return close(sessionAttributes, "Fulfilled", message)
    if analysis == 'Melanoma':
        if isChanging is None:
            messageText = "Is it changing in size or color?"
            return get_slot_value(sessionAttributes,intentName, 'isChanging',messageText, yesNo)
        elif try_ex(lambda: sessionAttributes['isChanging']) is None:
            sessionAttributes['isChanging'] = isChanging
            
        if injury is None:
            messageText = "Did you have any injury to the area?"
            return get_slot_value(sessionAttributes,intentName, 'injury',messageText, yesNo)
            # return elicit_slot(sessionAttributes, intentName, itching, )
        elif try_ex(lambda: sessionAttributes['injury']) is None:
            sessionAttributes['injury'] = injury
        
       
        message = """
        By looking at the image and based upon your inputs, we have diagnosed this condition as <b>Melanoma.</b>
        <br><b style="color:red"> Please don't neglect this condition. </b> Consult a doctor immediately as it looks like a Melanoma. If treated early, Melanoma can be cured completely.
        <br><b> Thanks for using DermoBot. Is there anything else I can help you with?</b>
        """
        logger.debug("Returning the message:")
        logger.debug(message)
        sessionAttributes={}
        return close(sessionAttributes, "Fulfilled", message)

    return close(sessionAttributes, "Fulfilled", "Currenly we are having an internal problem. Try after some time")
      
def dispatch(intentRequest):
    """
    Called when the user specifies an intent for this bot.
    """
    intentName = intentRequest['interpretations'][0]['intent']['name'] 

    # Dispatch to your bot's intent handlers
    if intentName == 'GenericSkinIssuesIntent':
        resp = handle_skin_issue(intentRequest)
        logger.debug("Response message:")
        logger.debug(resp)
        return resp

    raise Exception('Intent with name ' + intentName + ' not supported')

def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    """
    logger.debug("Received message:")
    logger.debug(event)
    # By default, treat the user request as coming from the America/New_York time zone.
    return dispatch(event)